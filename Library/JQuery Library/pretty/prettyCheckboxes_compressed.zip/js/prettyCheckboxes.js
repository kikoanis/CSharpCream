/* ------------------------------------------------------------------------
	prettyCheckboxes
	
	Developped By: Stephane Caron (http://www.no-margin-for-errors.com)
	Inspired By: All the non user friendly custom checkboxes solutions ;)
	Version: 1.0.1
	
	Copyright: Feel free to redistribute the script/modify it, as
			   long as you leave my infos at the top.
------------------------------------------------------------------------- */
	
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('q.D.E=5(a){a=q.F({j:r,s:r,t:\'G\',u:\'H\'},a);$(0).h(5(){$3=$(\'3[4="\'+$(0).1(\'d\')+\'"]\');$3.I("<9 v=\'w\'><9 v=\'x\'></9></9>");7($(0).k(\':2\')){$3.c(\'2\')};$3.c(a.t).c($(0).1(\'l\')).c(a.u);$3.i(\'9.w\').y(a.j).J(a.s);$3.i(\'9.x\').y(a.j);$(0).c(\'K\');$3.z(\'8\',5(){$(\'6#\'+$(0).1(\'4\')).L(\'8\');7($(\'6#\'+$(0).1(\'4\')).k(\':m\')){$(0).A(\'2\');$(\'6#\'+$(0).1(\'4\')).2=B}f{$n=$(\'6#\'+$(0).1(\'4\'));$(\'6[C="\'+$n.1(\'C\')+\'"]\').h(5(){$(\'3[4="\'+$(0).1(\'d\')+\'"]\').M(\'2\')});$(0).c(\'2\');$n.2=B}});$(\'6#\'+$3.1(\'4\')).z(\'N\',5(e){7(e.O==P){7($.o.p){$(\'3[4="\'+$(0).1(\'d\')+\'"]\').A("2")}f{$(0).g(\'8\')}Q R}})})};S=5(a,b){7($(a).k(\':2\')){$(b).i(\'6[l=m]:T(:2)\').h(5(){$(\'3[4="\'+$(0).1(\'d\')+\'"]\').g(\'8\');7($.o.p){$(0).1(\'2\',\'2\')}f{$(0).g(\'8\')}})}f{$(b).i(\'6[l=m]:2\').h(5(){$(\'3[4="\'+$(0).1(\'d\')+\'"]\').g(\'8\');7($.o.p){$(0).1(\'2\',\'\')}f{$(0).g(\'8\')}})}};',56,56,'this|attr|checked|label|for|function|input|if|click|span|||addClass|id||else|trigger|each|find|checkboxWidth|is|type|checkbox|toCheck|browser|msie|jQuery|17|checkboxHeight|className|display|class|holderWrap|holder|width|bind|toggleClass|true|name|fn|prettyCheckboxes|extend|prettyCheckbox|list|prepend|height|hiddenCheckbox|triggerHandler|removeClass|keypress|keyCode|32|return|false|checkAllPrettyCheckboxes|not'.split('|'),0,{}))