/* ------------------------------------------------------------------------
	Pretty Comments
	
	Developped By: Stephane Caron (http://www.no-margin-for-errors.com)
	Inspired By: The facebook textarea :)
	Version: 1.4
	
	Copyright: Feel free to redistribute the script/modify it, as
			   long as you leave my infos at the top.
------------------------------------------------------------------------- */

	eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('$.C.D=4(b){b=E.F({8:i,o:\'G\',j:H,5:i,p:q},b);$(\'I\').J(\'<t K="1"></t>\');k c=4(a){$("#1").2({\'L\':\'M\',\'N\':-u,\'O\':-u,\'v\':$(a).v(),\'P-0\':$(a).0(),\'l-w\':$(a).2(\'l-w\'),\'l-x\':$(a).2(\'l-x\'),\'z-0\':$(a).2(\'z-0\')});3($.A.Q&&R($.A.S)<7){$("#1").2(\'0\',$(a).0())}};k d=4(a){m=$(a).T(\'U\')||"";m=m.V(/\\n/g,\'<B />\');$("#1").W(m+\'<B />\');3(!b.p){3($("#1").0()>$(a).0()){3($(\'#1\').0()>b.j){$(a).2(\'9-y\',\'r\')}h{$(a).2(\'9-y\',\'s\');e(a)}}h 3($("#1").0()<$(a).0()){3($(\'#1\').0()>b.j){$(a).2(\'9-y\',\'r\')}h{$(a).2(\'9-y\',\'s\');f(a)}}}};k e=4(a){3(b.8&&!b.5){b.5=q;$(a).8({\'0\':$("#1").0()},b.o,4(){b.5=i})}h 3(!b.8&&!b.5){$(a).0($("#1").0())}};k f=4(a){3(b.8&&!b.5){b.5=q;$(a).8({\'0\':$("#1").0()},b.o,4(){b.5=i})}h{$(a).0($("#1").0())}};$(6).X(4(){$(6).2({\'9\':\'s\'}).Y(\'Z\',4(){d($(6))});c(6);d($(6));3($("#1").0()>b.j){$(6).2({\'9-y\':\'r\',\'0\':b.j})}h{$(6).0($("#1").0())};b.p=i})};',62,62,'height|comment_hidden|css|if|function|alreadyAnimated|this||animate|overflow||||||||else|false|maxHeight|var|font|theValue||animationSpeed|init|true|scroll|hidden|div|10000|width|family|size||line|browser|br|fn|prettyComments|jQuery|extend|fast|500|body|append|id|position|absolute|top|left|min|msie|parseFloat|version|attr|value|replace|html|each|bind|keyup'.split('|'),0,{}))